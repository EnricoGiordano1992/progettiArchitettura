pdflatex Relazione.tex
pdflatex Relazione-frn.tex
pdflatex Relazione.tex

evince Relazione.pdf

